# -*- coding: utf-8 -*-
"""
Created on Thu Oct 20 10:53:43 2022

@author: gitan
"""

import numpy as np
import matplotlib.pyplot as plt
np.random.seed(17)
x = np.random.uniform(-5, 5, 100)
y = [12*i-4 for i in x]
print(y)
plt.scatter(x, y, alpha=0.5)
plt.title("Scatter Plot (X vs Y)")
plt.xlabel("X")
plt.ylabel("y")
np.random.seed(17)
noise = np.random.normal(-15, 15, 100)
print(noise)
noiseY = [a + b for a, b in zip(y, noise)]
plt.scatter(x, noiseY, alpha=0.5)
plt.title("Scatter Plot (X vs noiseY)")
plt.xlabel("X")
plt.ylabel("y_noise")